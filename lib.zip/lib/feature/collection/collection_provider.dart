// lib/feature/collection/collection_provider.dart

import 'dart:async';

import 'package:animeshin/anilibria/anilibria_repository.dart';
import 'package:animeshin/extension/iterable_extension.dart';
import 'package:animeshin/util/notification_system.dart';
import 'package:animeshin/util/text_utils.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animeshin/extension/date_time_extension.dart';
import 'package:animeshin/feature/viewer/persistence_provider.dart';
import 'package:animeshin/feature/collection/collection_models.dart';
import 'package:animeshin/feature/home/home_provider.dart';
import 'package:animeshin/feature/media/media_models.dart';
import 'package:animeshin/feature/viewer/repository_provider.dart';
import 'package:animeshin/util/graphql.dart';

/// Toggle the extra/fallback search for missed aliases.
/// Set to false if you want only the fast bulk lookup.
const bool kEnableFallbackSearch = true;

/// Upper bound on how many misses we try to rescue per page.
/// Keeps the UI snappy even on huge collections.
const int kMaxFallbackPerPage = 10;

/// Concurrency for fallback searches (4 keeps it quick but polite).
const int _kSearchConcurrency = 4;

final collectionProvider = AsyncNotifierProvider.autoDispose
    .family<CollectionNotifier, Collection, CollectionTag>(
  CollectionNotifier.new,
);

class CollectionNotifier
    extends AutoDisposeFamilyAsyncNotifier<Collection, CollectionTag> {
  var _sort = EntrySort.title;

  @override
  FutureOr<Collection> build(arg) async {
    final index = switch (state.valueOrNull) {
      FullCollection c => c.index,
      _ => 0,
    };

    final viewerId = ref.watch(viewerIdProvider);

    final isFull = arg.userId != viewerId ||
        ref.watch(homeProvider.select(
          (s) => arg.ofAnime
              ? s.didExpandAnimeCollection
              : s.didExpandMangaCollection,
        ));

    final data = await ref.read(repositoryProvider).request(
      GqlQuery.collection,
      {
        'userId': arg.userId,
        'type': arg.ofAnime ? 'ANIME' : 'MANGA',
        if (!isFull) 'status_in': ['CURRENT', 'REPEATING'],
      },
    );

    // Use robust alias generator (handles punctuation/diacritics)
    String toKebabCase(String input) => toKebabAlias(input);

    final anilibriaRepo = AnilibriaRepository();

    // Build AniList-derived alias list and quick lookup
    final List<String> aliases = [];
    final Map<String, Map<String, dynamic>> entriesByAlias = {};
    for (final l in data['MediaListCollection']['lists']) {
      for (final e in l['entries']) {
        final alias = toKebabCase(e['media']['title']['romaji']);
        aliases.add(alias);
        entriesByAlias[alias] = e;
      }
    }

    // Bulk fetch Anilibria by aliases
    final anilibriaData = await anilibriaRepo.fetchListByAliases(
      aliases: aliases,
      include: ['name', 'episodes', 'alias'],
      exclude: [
        'name.english',
        'name.alternative',
        'episodes.id',
        'episodes.name',
        'episodes.opening',
        'episodes.ending',
        'episodes.preview',
        'episodes.hls_480',
        'episodes.hls_720',
        'episodes.hls_1080',
        'episodes.duration',
        'episodes.rutube_id',
        'episodes.youtube_id',
        'episodes.updated_at',
        'episodes.sort_order',
        'episodes.release_id',
        'episodes.name_english'
      ],
    );

    final dataList = anilibriaData['data'] as List<dynamic>;
    final Map<String, dynamic> anilibriaByAlias = {};
    for (final item in dataList) {
      if (item['alias'] != null) {
        anilibriaByAlias[item['alias']] = item;
      }
    }

    // Figure out which aliases were missed in the bulk request
    final missingAliases =
        aliases.where((a) => !anilibriaByAlias.containsKey(a)).toList();

    // Try to enrich the misses using a bounded, cached, concurrent search
    await _enrichMissingWithSearch(
      missingAliases,
      entriesByAlias,
      anilibriaByAlias,
      anilibriaRepo,
    );

    // Merge back into entries: add ruTitle and last episode ordinal
    for (final l in data['MediaListCollection']['lists']) {
      for (final e in l['entries']) {
        final entryAlias = toKebabCase(e['media']['title']['romaji']);
        final aniItem = anilibriaByAlias[entryAlias];
        if (aniItem != null) {
          final ruTitle = aniItem['name']?['main'];
          final episodes = aniItem['episodes'] as List<dynamic>?;
          if (ruTitle != null) e['media']['title']['russian'] = ruTitle;
          if (episodes != null && episodes.isNotEmpty) {
            e['media']['anilibriaLastEpisode'] = episodes.last['ordinal'];
          }
        }
      }
    }

    final imageQuality = ref.read(persistenceProvider).options.imageQuality;

    final collection = isFull
        ? FullCollection(
            data['MediaListCollection'],
            arg.ofAnime,
            index,
            imageQuality,
          )
        : PreviewCollection(data['MediaListCollection'], imageQuality);
    collection.sort(_sort);

    await NotificationSystem.scheduleNotificationsForAll(collection.list.entries);

    return collection;
  }

  void ensureSorted(EntrySort sort, EntrySort previewSort) {
    _updateState((collection) {
      final selectedSort = switch (collection) {
        FullCollection _ => sort,
        PreviewCollection _ => previewSort,
      };

      if (_sort == selectedSort) return;
      _sort = selectedSort;

      collection.sort(selectedSort);
      return null;
    });
  }

  void changeIndex(int newIndex) => _updateState(
        (collection) => switch (collection) {
          FullCollection _ => collection.withIndex(newIndex),
          PreviewCollection _ => collection,
        },
      );

  void removeEntry(int mediaId) {
    _updateState(
      (collection) => switch (collection) {
        PreviewCollection c => c..list.removeByMediaId(mediaId),
        FullCollection c => _withRemovedEmptyLists(
            c..lists.forEach((list) => list.removeByMediaId(mediaId)),
          ),
      },
    );
  }

  /// There is an api bug in entry updating,
  /// which prevents tag data from being returned.
  /// This is why [saveEntry] additionally fetches the updated entry.
  Future<void> saveEntry(int mediaId, ListStatus? oldStatus) async {
    try {
      var data = await ref.read(repositoryProvider).request(
        GqlQuery.listEntry,
        {'userId': arg.userId, 'mediaId': mediaId},
      );
      data = data['MediaList'];

      Entry? oldEntry;
      final collection = state.valueOrNull;
      if (collection is FullCollection) {
        for (final list in collection.lists) {
          oldEntry = list.entries.firstWhereOrNull((e) => e.mediaId == mediaId);
          if (oldEntry != null) break;
        }
      } else if (collection is PreviewCollection) {
        oldEntry = collection.list.entries.firstWhereOrNull((e) => e.mediaId == mediaId);
      }

      final entry = Entry(
        data,
        ref.read(persistenceProvider).options.imageQuality,
      );

      if (oldEntry != null) {
        entry.ruTitle = oldEntry.ruTitle;
        entry.ruLastEpisode = oldEntry.ruLastEpisode;
      }

      await NotificationSystem.scheduleNotificationForEntry(entry);

      _updateState(
        (collection) => switch (collection) {
          FullCollection _ => _saveEntryInFullCollection(
              collection,
              entry,
              oldStatus,
              data,
            ),
          PreviewCollection _ => _saveEntryInPreviewCollection(
              collection,
              entry,
              oldStatus,
              entry.listStatus,
            ),
        },
      );
    } catch (_) {}
  }

  /// An alternative to [saveEntry],
  /// that only updates the progress and potentially, the list status.
  /// When incrementing to last episode, [saveEntry] should be called instead.
  Future<String?> saveEntryProgress(
    Entry oldEntry,
    bool setAsCurrent,
  ) async {
    try {
      await ref.read(repositoryProvider).request(
        GqlMutation.updateProgress,
        {
          'mediaId': oldEntry.mediaId,
          'progress': oldEntry.progress,
          if (setAsCurrent) ...{
            'status': ListStatus.current.value,
            if (oldEntry.watchStart == null)
              'startedAt': DateTime.now().fuzzyDate,
          },
        },
      );

      await saveEntry(oldEntry.mediaId, oldEntry.listStatus);

      return null;
    } catch (e) {
      return e.toString();
    }
  }

  FullCollection _saveEntryInFullCollection(
    FullCollection collection,
    Entry entry,
    ListStatus? oldStatus,
    Map<String, dynamic> data,
  ) {
    final hiddenFromStatusLists = data['hiddenFromStatusLists'] ?? false;
    final customListItems = data['customLists'] ?? const <String, dynamic>{};
    final customLists = customListItems.entries
        .where((e) => e.value == true)
        .map((e) => e.key.toLowerCase())
        .toList();

    for (final list in collection.lists) {
      if (list.status != null) {
        if (list.status == oldStatus) {
          if (list.status == entry.listStatus) {
            if (hiddenFromStatusLists) {
              list.removeByMediaId(entry.mediaId);
              continue;
            }

            if (!list.setByMediaId(entry)) {
              list.insertSorted(entry, _sort);
            }

            continue;
          }

          list.removeByMediaId(entry.mediaId);
          continue;
        }

        if (list.status == entry.listStatus) {
          list.insertSorted(entry, _sort);
        }

        continue;
      }

      if (customLists.contains(list.name.toLowerCase())) {
        if (!list.setByMediaId(entry)) {
          list.insertSorted(entry, _sort);
        }

        continue;
      }

      list.removeByMediaId(entry.mediaId);
    }

    return _withRemovedEmptyLists(collection);
  }

  PreviewCollection _saveEntryInPreviewCollection(
    PreviewCollection collection,
    Entry entry,
    ListStatus? oldStatus,
    ListStatus? newStatus,
  ) {
    if (newStatus == ListStatus.current || newStatus == ListStatus.repeating) {
      if (oldStatus == ListStatus.current ||
          oldStatus == ListStatus.repeating) {
        collection.list.setByMediaId(entry);
        return collection;
      }

      collection.list.insertSorted(entry, _sort);
      return collection;
    }

    collection.list.removeByMediaId(entry.mediaId);
    return collection;
  }

  FullCollection _withRemovedEmptyLists(FullCollection collection) {
    final lists = collection.lists;
    int index = collection.index;

    for (int i = 0; i < lists.length; i++) {
      if (lists[i].entries.isEmpty) {
        if (i <= index && index != 0) index--;
        lists.removeAt(i--);
      }
    }

    return collection.withIndex(index);
  }

  void _updateState(Collection? Function(Collection) mutator) {
    if (!state.hasValue) return;
    final result = mutator(state.value!);
    if (result != null) state = AsyncValue.data(result);
  }
}

/// Concurrent, bounded enrichment for missed aliases.
/// Keeps UI responsive while still rescuing some items.
Future<void> _enrichMissingWithSearch(
  List<String> missingAliases,
  Map<String, dynamic> entriesByAlias,
  Map<String, dynamic> anilibriaByAlias,
  AnilibriaRepository repo,
) async {
  if (!kEnableFallbackSearch) return;

  // Bound the amount of extra work per page load.
  final targets = missingAliases.take(kMaxFallbackPerPage).toList();

  // Fields to request (keep it light).
  final _include = ['name', 'episodes', 'alias'];
  final _exclude = [
    'name.english',
    'name.alternative',
    'episodes.id',
    'episodes.name',
    'episodes.opening',
    'episodes.ending',
    'episodes.preview',
    'episodes.hls_480',
    'episodes.hls_720',
    'episodes.hls_1080',
    'episodes.duration',
    'episodes.rutube_id',
    'episodes.youtube_id',
    'episodes.updated_at',
    'episodes.sort_order',
    'episodes.release_id',
    'episodes.name_english'
  ];

  // Small concurrency pool
  final pool = <Future<void>>[];
  for (final alias in targets) {
    pool.add(() async {
      final e = entriesByAlias[alias];
      if (e == null) return;

      final media = (e['media'] as Map<String, dynamic>?);
      final titles = (media?['title'] as Map<String, dynamic>?) ?? const {};
      final romaji = (titles['romaji'] ?? '').toString();
      final english = (titles['english'] ?? '').toString();

      final foundAlias = await repo.searchBestAlias(
        romajiTitle: romaji,
        englishTitle: english.isEmpty ? null : english,
      );

      if (foundAlias == null) return;

      final single = await repo.fetchListByAliases(
        aliases: [foundAlias],
        include: _include,
        exclude: _exclude,
      );
      final items = (single['data'] as List<dynamic>?);
      if (items != null && items.isNotEmpty) {
        anilibriaByAlias[alias] = items.first;
      }
    }());

    if (pool.length == _kSearchConcurrency) {
      await Future.wait(pool);
      pool.clear();
    }
  }
  if (pool.isNotEmpty) await Future.wait(pool);
}
